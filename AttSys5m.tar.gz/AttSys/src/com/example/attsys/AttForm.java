package com.example.attsys;

import java.util.ArrayList;
import java.util.Calendar;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

public class AttForm extends Activity {
	String pob;
	int imc_met;
	private EditText etDate;
	private Spinner spin1;
	private Spinner spin2;
	private Spinner spin3;
	
	private ImageButton change_date;
	final int Date_Dialog_ID=0;
	int cDay,cMonth,cYear; // this is the instances of the current date
	private Calendar cDate;
	int sDay,sMonth,sYear; // this is the instances of the entered date

	ArrayList<String> a = new ArrayList<String>();
	ArrayList<String> b = new ArrayList<String>();
	
	
	ArrayList<String> ce_8_sub = new ArrayList<String>();
	ArrayList<String> it_8_sub = new ArrayList<String>();
	ArrayList<String> ee_8_sub = new ArrayList<String>();
	ArrayList<String> c_8_sub = new ArrayList<String>();
	ArrayList<String> m_8_sub = new ArrayList<String>();

	ArrayList<String> ce_7_sub = new ArrayList<String>();
	ArrayList<String> it_7_sub = new ArrayList<String>();
	ArrayList<String> ee_7_sub = new ArrayList<String>();
	ArrayList<String> c_7_sub = new ArrayList<String>();
	ArrayList<String> m_7_sub = new ArrayList<String>();

	ArrayList<String> ce_6_sub = new ArrayList<String>();
	ArrayList<String> it_6_sub = new ArrayList<String>();
	ArrayList<String> ee_6_sub = new ArrayList<String>();
	ArrayList<String> c_6_sub = new ArrayList<String>();
	ArrayList<String> m_6_sub = new ArrayList<String>();

	ArrayList<String> ce_5_sub = new ArrayList<String>();
	ArrayList<String> it_5_sub = new ArrayList<String>();
	ArrayList<String> ee_5_sub = new ArrayList<String>();
	ArrayList<String> c_5_sub = new ArrayList<String>();
	ArrayList<String> m_5_sub = new ArrayList<String>();

	ArrayList<String> ce_4_sub = new ArrayList<String>();
	ArrayList<String> it_4_sub = new ArrayList<String>();
	ArrayList<String> ee_4_sub = new ArrayList<String>();
	ArrayList<String> c_4_sub = new ArrayList<String>();
	ArrayList<String> m_4_sub = new ArrayList<String>();

	ArrayList<String> ce_3_sub = new ArrayList<String>();
	ArrayList<String> it_3_sub = new ArrayList<String>();
	ArrayList<String> ee_3_sub = new ArrayList<String>();
	ArrayList<String> c_3_sub = new ArrayList<String>();
	ArrayList<String> m_3_sub = new ArrayList<String>();

	ArrayList<String> ce_2_sub = new ArrayList<String>();
	ArrayList<String> it_2_sub = new ArrayList<String>();
	ArrayList<String> ee_2_sub = new ArrayList<String>();
	ArrayList<String> c_2_sub = new ArrayList<String>();
	ArrayList<String> m_2_sub = new ArrayList<String>();

	ArrayList<String> ce_1_sub = new ArrayList<String>();
	ArrayList<String> it_1_sub = new ArrayList<String>();
	ArrayList<String> ee_1_sub = new ArrayList<String>();
	ArrayList<String> c_1_sub = new ArrayList<String>();
	ArrayList<String> m_1_sub = new ArrayList<String>();
				
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attform);
		
		
		
		etDate=(EditText)findViewById(R.id.dateid);
		change_date=(ImageButton)findViewById(R.id.imageButton1);
		spin1 = (Spinner) findViewById(R.id.selectbranch);
		spin2 = (Spinner) findViewById(R.id.selectsemid);
		spin3 = (Spinner) findViewById(R.id.selectsubid);
		
		//getting current date
		cDate=Calendar.getInstance();
		cDay=cDate.get(Calendar.DAY_OF_MONTH);
		cMonth=cDate.get(Calendar.MONTH);
		cYear=cDate.get(Calendar.YEAR);
		//assigning the edittext with the current date in the beginning
		sDay=cDay;
		sMonth=cMonth;
		sYear=cYear;
		updateDateDisplay(sYear,sMonth,sDay);
		
		change_date.setOnClickListener(new OnClickListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//triggers the DatePickerDialog
				showDialog(Date_Dialog_ID);
			}
		});
		
		fillarray();
		
		spin1.setAdapter(new ArrayAdapter<String>(AttForm.this,
				android.R.layout.simple_dropdown_item_1line, a));
		spin1.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				pob= spin1.getSelectedItem().toString();

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}	});

		
//		pob= spin1.getSelectedItem().toString();
		
		
		spin2.setAdapter(new ArrayAdapter<String>(AttForm.this,
				android.R.layout.simple_dropdown_item_1line, b));  

		spin2.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				imc_met=spin2.getSelectedItemPosition();


				if(pob.equals("Computer Engineering") )
				{

					switch (imc_met) 
					{
					

					default:
					
						break;
					case 0:

						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_1_sub));
						spin3.getAdapter();
						break;

					case 1:
						
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_2_sub));
						spin3.getAdapter();
						break;

					
					case 2:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_3_sub));
						spin3.getAdapter();

						break;
					case 3:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_4_sub));
						spin3.getAdapter();

						break;
					case 4:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_5_sub));
						spin3.getAdapter();


						break;
					case 5:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_6_sub));
						spin3.getAdapter();


						break;
					case 6:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_7_sub));
						spin3.getAdapter();


						break;
					case 7:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ce_8_sub));
						spin3.getAdapter();


						break;

					}
				}



				if(pob.equals("Information Technology") )
				{

					switch (imc_met) 
					{
					case 0:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_1_sub));
						spin3.getAdapter();


						break;

					case 1:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_2_sub));
						spin3.getAdapter();

						break;
					case 2:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_3_sub));
						spin3.getAdapter();

						break;
					case 3:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_4_sub));
						spin3.getAdapter();

						break;
					case 4:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_5_sub));
						spin3.getAdapter();

						break;
					case 5:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_6_sub));
						spin3.getAdapter();

						break;
					case 6:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_7_sub));
						spin3.getAdapter();

						break;
					case 7:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, it_6_sub));
						spin3.getAdapter();

						break;

					default:
					
						break;
					}


				}

				if(pob.equals("Electronics and Electrical Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_1_sub));
						spin3.getAdapter();


						break;

					case 1:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_2_sub));
						spin3.getAdapter();

						break;
					case 2:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_3_sub));
						spin3.getAdapter();

						break;
					case 3:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_4_sub));
						spin3.getAdapter();

						break;
					case 4:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_5_sub));
						spin3.getAdapter();

						break;
					case 5:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_6_sub));
						spin3.getAdapter();

						break;
					case 6:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_7_sub));
						spin3.getAdapter();

						break;
					case 7:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, ee_8_sub));
						spin3.getAdapter();

						break;

					default:
					
						break;
					}
				}

				if(pob.equals("Civil Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_1_sub));
						spin3.getAdapter();


						break;

					case 1:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_2_sub));
						spin3.getAdapter();

						break;
					case 2:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_3_sub));
						spin3.getAdapter();

						break;
					case 3:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_4_sub));
						spin3.getAdapter();

						break;
					case 4:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_5_sub));
						spin3.getAdapter();

						break;
					case 5:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_6_sub));
						spin3.getAdapter();

						break;
					case 6:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_7_sub));
						spin3.getAdapter();

						break;
					case 7:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, c_8_sub));
						spin3.getAdapter();

						break;

					default:
					
						break;
					}
				}

				if(pob.equals("Mechanical Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_1_sub));
						spin3.getAdapter();


						break;

					case 1:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_2_sub));
						spin3.getAdapter();

						break;
					case 2:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_3_sub));
						spin3.getAdapter();

						break;
					case 3:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_4_sub));
						spin3.getAdapter();

						break;
					case 4:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_5_sub));
						spin3.getAdapter();

						break;
					case 5:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_6_sub));
						spin3.getAdapter();

						break;
					case 6:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_7_sub));
						spin3.getAdapter();

						break;
					case 7:
						spin3.setAdapter(new ArrayAdapter<String>(
								AttForm.this,
								android.R.layout.simple_dropdown_item_1line, m_8_sub));
						spin3.getAdapter();

						break;

					default:
						
						break;
					}
				}

		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub

		}
	});

		
	}
	
	 public void backmethod(View v)
	    {
	    	startActivity(new Intent(this, HomeActivity.class));
	    }
	 
	 @SuppressWarnings("deprecation")
		public void infomethod(View v){
	    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
	    	alertDialog.setTitle("Sorry");
	    	alertDialog.setMessage("Temporary Data Connection Stop");
	    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
	    	   public void onClick(DialogInterface dialog, int which) {
	    	      // TODO Add your code for the button here.
	    	   }
	    	});
	    	// Set the Icon for the Dialog
	    	alertDialog.setIcon(R.drawable.udimage);
	    	alertDialog.show();
	    }
	 
	
	protected Dialog onCreateDialog(int id) {
		 
		switch (id) {
		case Date_Dialog_ID:
		return new DatePickerDialog(this, onDateSet, cYear, cMonth,
		cDay);
		}
		return null;
	}
		 
	private void updateDateDisplay(int year,int month,int date) {
		// TODO Auto-generated method stub
		etDate.setText(date+"-"+(month+1)+"-"+year);
	}
	
	private OnDateSetListener onDateSet=new OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth){
			// TODO Auto-generated method stub
			System.out.println("2");
			sYear=year;
			sMonth=monthOfYear;
			sDay=dayOfMonth;
			updateDateDisplay(sYear,sMonth,sDay);
		}
	};
		  
/******* spinner*********/

	private void fillarray() {
	// TODO Auto-generated method stub
	a.clear();
	a.add("Computer Engineering");
	a.add("Information Technology");
	a.add("Electronics and Electrical Engineering");
	a.add("Civil Engineering");
	a.add("Mechanical Engineering");
	

	b.clear();
	b.add("1");
	b.add("2");
	b.add("3");
	b.add("4");
	b.add("5");
	b.add("6");
	b.add("7");
	b.add("8");
	
	
	// 8sem sub start here
	ce_8_sub.clear();
	ce_8_sub.add("CE sub1 for 8sem");
	ce_8_sub.add("CE sub2 for 8sem");
	ce_8_sub.add("CE sub3 for 8sem");
	ce_8_sub.add("CE sub4 for 8sem");

	it_8_sub.clear();
	it_8_sub.add("IT sub1 for 8sem");
	it_8_sub.add("IT sub1 for 8sem");
	it_8_sub.add("IT sub1 for 8sem");
	it_8_sub.add("IT sub1 for 8sem");


	c_8_sub.clear();
	c_8_sub.add("Civil sub 1 for 8sem");
	c_8_sub.add("Civil sub 2 for 8sem");
	c_8_sub.add("Civil sub 3 for 8sem");
	c_8_sub.add("Civil sub 4 for 8sem");

	ee_8_sub.clear();
	ee_8_sub.add("EEE sub 1for 8sem");
	ee_8_sub.add("EEE sub 2for 8sem");
	ee_8_sub.add("EEE sub 3for 8sem");
	ee_8_sub.add("EEE sub 4for 8sem");

	m_8_sub.clear();
	m_8_sub.add("Mech sub 1for 8sem");
	m_8_sub.add("Mech sub 1for 8sem");
	m_8_sub.add("Mech sub 1for 8sem");
	m_8_sub.add("Mech sub 1for 8sem");
	//  8 sem subject over here   

	// 7 sem sub start here
	ce_7_sub.clear();
	ce_7_sub.add("CE sub1 for 7sem");
	ce_7_sub.add("CE sub2 for 7sem");
	ce_7_sub.add("CE sub3 for 7sem");
	ce_7_sub.add("CE sub4 for 7sem");

	it_7_sub.clear();
	it_7_sub.add("IT sub1 for 7sem");
	it_7_sub.add("IT sub1 for 7sem");
	it_7_sub.add("IT sub1 for 7sem");
	it_7_sub.add("IT sub1 for 7sem");


	c_7_sub.clear();
	c_7_sub.add("Civil sub 1 for 7sem");
	c_7_sub.add("Civil sub 2 for 7sem");
	c_7_sub.add("Civil sub 3 for 7sem");
	c_7_sub.add("Civil sub 4 for 7sem");

	ee_7_sub.clear();
	ee_7_sub.add("EEE sub 1for 7sem");
	ee_7_sub.add("EEE sub 2for 7sem");
	ee_7_sub.add("EEE sub 3for 7sem");
	ee_7_sub.add("EEE sub 4for 7sem");

	m_7_sub.clear();
	m_7_sub.add("Mech sub 1for 7sem");
	m_7_sub.add("Mech sub 1for 7sem");
	m_7_sub.add("Mech sub 1for 7sem");
	m_7_sub.add("Mech sub 1for 7sem");
	// 7 sem sub over here.....

	// 6 sem sub start here....		    
	ce_6_sub.clear();
	ce_6_sub.add("CE sub1 for 6sem");
	ce_6_sub.add("CE sub2 for 6sem");
	ce_6_sub.add("CE sub3 for 6sem");
	ce_6_sub.add("CE sub4 for 6sem");

	it_6_sub.clear();
	it_6_sub.add("IT sub1 for 6sem");
	it_6_sub.add("IT sub1 for 6sem");
	it_6_sub.add("IT sub1 for 6sem");
	it_6_sub.add("IT sub1 for 6sem");


	c_6_sub.clear();
	c_6_sub.add("Civil sub 1 for 6sem");
	c_6_sub.add("Civil sub 2 for 6sem");
	c_6_sub.add("Civil sub 3 for 6sem");
	c_6_sub.add("Civil sub 4 for 6sem");

	ee_6_sub.clear();
	ee_6_sub.add("EEE sub 1for 6sem");
	ee_6_sub.add("EEE sub 2for 6sem");
	ee_6_sub.add("EEE sub 3for 6sem");
	ee_6_sub.add("EEE sub 4for 6sem");

	m_6_sub.clear();
	m_6_sub.add("Mech sub 1for 6sem");
	m_6_sub.add("Mech sub 1for 6sem");
	m_6_sub.add("Mech sub 1for 6sem");
	m_6_sub.add("Mech sub 1for 6sem");

	// 6 sem sub over here
	// 5 sem sub start
	ce_5_sub.clear();
	ce_5_sub.add("CE sub1 for 5sem");
	ce_5_sub.add("CE sub2 for 5sem");
	ce_5_sub.add("CE sub3 for 5sem");
	ce_5_sub.add("CE sub4 for 5sem");

	it_5_sub.clear();
	it_5_sub.add("IT sub1 for 5sem");
	it_5_sub.add("IT sub1 for 5sem");
	it_5_sub.add("IT sub1 for 5sem");
	it_5_sub.add("IT sub1 for 5sem");


	c_5_sub.clear();
	c_5_sub.add("Civil sub 1 for 5sem");
	c_5_sub.add("Civil sub 2 for 5sem");
	c_5_sub.add("Civil sub 3 for 5sem");
	c_5_sub.add("Civil sub 4 for 5sem");

	ee_5_sub.clear();
	ee_5_sub.add("EEE sub 1for 5sem");
	ee_5_sub.add("EEE sub 2for 5sem");
	ee_5_sub.add("EEE sub 3for 5sem");
	ee_5_sub.add("EEE sub 4for 5sem");

	m_5_sub.clear();
	m_5_sub.add("Mech sub 1for 5sem");
	m_5_sub.add("Mech sub 1for 5sem");
	m_5_sub.add("Mech sub 1for 5sem");
	m_5_sub.add("Mech sub 1for 5sem");

	// 5 sem sub over here
	// 4 sem sub start

	ce_4_sub.clear();
	ce_4_sub.add("CE sub1 for 4sem");
	ce_4_sub.add("CE sub2 for 4sem");
	ce_4_sub.add("CE sub3 for 4sem");
	ce_4_sub.add("CE sub4 for 4sem");

	it_4_sub.clear();
	it_4_sub.add("IT sub1 for 4sem");
	it_4_sub.add("IT sub1 for 4sem");
	it_4_sub.add("IT sub1 for 4sem");
	it_4_sub.add("IT sub1 for 4sem");


	c_4_sub.clear();
	c_4_sub.add("Civil sub 1 for 4sem");
	c_4_sub.add("Civil sub 2 for 4sem");
	c_4_sub.add("Civil sub 3 for 4sem");
	c_4_sub.add("Civil sub 4 for 4sem");

	ee_4_sub.clear();
	ee_4_sub.add("EEE sub 1for 4sem");
	ee_4_sub.add("EEE sub 2for 4sem");
	ee_4_sub.add("EEE sub 3for 4sem");
	ee_4_sub.add("EEE sub 4for 4sem");

	m_4_sub.clear();
	m_4_sub.add("Mech sub 1for 4sem");
	m_4_sub.add("Mech sub 1for 4sem");
	m_4_sub.add("Mech sub 1for 4sem");
	m_4_sub.add("Mech sub 1for 4sem");

	// 4 sem sub over here
	// 3 sem sub start
	ce_3_sub.clear();
	ce_3_sub.add("CE sub1 for 3sem");
	ce_3_sub.add("CE sub2 for 3sem");
	ce_3_sub.add("CE sub3 for 3sem");
	ce_3_sub.add("CE sub4 for 3sem");

	it_3_sub.clear();
	it_3_sub.add("IT sub1 for 3sem");
	it_3_sub.add("IT sub1 for 3sem");
	it_3_sub.add("IT sub1 for 3sem");
	it_3_sub.add("IT sub1 for 3sem");


	c_3_sub.clear();
	c_3_sub.add("Civil sub 1 for 3sem");
	c_3_sub.add("Civil sub 2 for 3sem");
	c_3_sub.add("Civil sub 3 for 3sem");
	c_3_sub.add("Civil sub 4 for 3sem");

	ee_3_sub.clear();
	ee_3_sub.add("EEE sub 1for 3sem");
	ee_3_sub.add("EEE sub 2for 3sem");
	ee_3_sub.add("EEE sub 3for 3sem");
	ee_3_sub.add("EEE sub 4for 3sem");

	m_3_sub.clear();
	m_3_sub.add("Mech sub 1for 3sem");
	m_3_sub.add("Mech sub 1for 3sem");
	m_3_sub.add("Mech sub 1for 3sem");
	m_3_sub.add("Mech sub 1for 3sem");

	// 3 sem sub over here
	// 2 sem sub start

	ce_2_sub.clear();
	ce_2_sub.add("CE sub1 for 2sem");
	ce_2_sub.add("CE sub2 for 2sem");
	ce_2_sub.add("CE sub3 for 2sem");
	ce_2_sub.add("CE sub4 for 2sem");

	it_2_sub.clear();
	it_2_sub.add("IT sub1 for 2sem");
	it_2_sub.add("IT sub1 for 2sem");
	it_2_sub.add("IT sub1 for 2sem");
	it_2_sub.add("IT sub1 for 2sem");


	c_2_sub.clear();
	c_2_sub.add("Civil sub 1 for 2sem");
	c_2_sub.add("Civil sub 2 for 23sem");
	c_2_sub.add("Civil sub 3 for 2sem");
	c_2_sub.add("Civil sub 4 for 2sem");

	ee_2_sub.clear();
	ee_2_sub.add("EEE sub 1for 2sem");
	ee_2_sub.add("EEE sub 2for 2sem");
	ee_2_sub.add("EEE sub 3for 2sem");
	ee_2_sub.add("EEE sub 4for 2sem");

	m_2_sub.clear();
	m_2_sub.add("Mech sub 1for 2sem");
	m_2_sub.add("Mech sub 1for 2sem");
	m_2_sub.add("Mech sub 1for 2sem");
	m_2_sub.add("Mech sub 1for 2sem");

	// 2 sem sub over here
	// 1 sem sub start
	ce_1_sub.clear();
	ce_1_sub.add("CE sub1 for 1sem");
	ce_1_sub.add("CE sub2 for 1sem");
	ce_1_sub.add("CE sub3 for 1sem");
	ce_1_sub.add("CE sub4 for 1sem");

	it_1_sub.clear();
	it_1_sub.add("IT sub1 for 1sem");
	it_1_sub.add("IT sub1 for 1sem");
	it_1_sub.add("IT sub1 for 1sem");
	it_1_sub.add("IT sub1 for 1sem");


	c_1_sub.clear();
	c_1_sub.add("Civil sub 1 for 1sem");
	c_1_sub.add("Civil sub 2 for 1sem");
	c_1_sub.add("Civil sub 3 for 1sem");
	c_1_sub.add("Civil sub 4 for 1sem");

	ee_1_sub.clear();
	ee_1_sub.add("EEE sub 1for 1sem");
	ee_1_sub.add("EEE sub 2for 1sem");
	ee_1_sub.add("EEE sub 3for 1sem");
	ee_1_sub.add("EEE sub 4for 1sem");

	m_1_sub.clear();
	m_1_sub.add("Mech sub 1for 1sem");
	m_1_sub.add("Mech sub 1for 1sem");
	m_1_sub.add("Mech sub 1for 1sem");
	m_1_sub.add("Mech sub 1for 1sem");
}
}




