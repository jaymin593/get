package com.example.attsys;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;



public class Login extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
         }

    
    public void loginmethod(View v)
    {
    	startActivity(new Intent(this, HomeActivity.class));
    }
    
    public void backmethod(View v)
    {
    	  finish();
          System.exit(0);
    }
    
    
    @SuppressWarnings("deprecation")
	public void infomethod(View v){
    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
    	alertDialog.setTitle("Sorry");
    	alertDialog.setMessage("Temporary Data Connection Stop");
    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
    	   public void onClick(DialogInterface dialog, int which) {
    	      // TODO Add your code for the button here.
    	   }
    	});
    	// Set the Icon for the Dialog
    	alertDialog.setIcon(R.drawable.udimage);
    	alertDialog.show();
    }
}